package Beans;

public enum ClientType {
    ADMINISTRATOR,COMPANY,CUSTOMER
}
