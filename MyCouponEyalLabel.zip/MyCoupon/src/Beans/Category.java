package Beans;

public enum Category {
    FOOD,ELECTRICITY,RESTAURANT,VACATION,FASHION
}
