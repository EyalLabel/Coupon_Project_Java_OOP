package Exceptions;

public class CouponException extends Exception{
    public CouponException(String message) {
        super(message);
    }
}
